// API Base URL
const API_BASE = window.location.origin

// Chart instances
let attackChart = null
let monitoringActive = false

// Initialize dashboard
document.addEventListener("DOMContentLoaded", () => {
  console.log("[v0] Initializing SentinelNet Dashboard...")

  // Initialize chart
  initializeAttackChart()

  // Load initial data
  refreshData()

  // Set up monitoring toggle
  document.getElementById("toggle-monitoring").addEventListener("click", toggleMonitoring)

  // Check monitoring status
  checkMonitoringStatus()

  // Auto-refresh every 5 seconds when monitoring is active
  setInterval(() => {
    if (monitoringActive) {
      refreshData()
    }
  }, 5000)

  console.log("[v0] Dashboard initialized successfully")
})

// Initialize attack distribution chart
function initializeAttackChart() {
  const ctx = document.getElementById("attack-chart").getContext("2d")

  attackChart = new window.Chart(ctx, {
    type: "doughnut",
    data: {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: ["#ef4444", "#f59e0b", "#8b5cf6", "#06b6d4", "#10b981"],
          borderColor: "#1e293b",
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            color: "#f1f5f9",
            padding: 15,
            font: {
              size: 12,
            },
          },
        },
        tooltip: {
          backgroundColor: "#1e293b",
          titleColor: "#f1f5f9",
          bodyColor: "#94a3b8",
          borderColor: "#334155",
          borderWidth: 1,
        },
      },
    },
  })
}

// Toggle monitoring
async function toggleMonitoring() {
  const button = document.getElementById("toggle-monitoring")
  const endpoint = monitoringActive ? "/api/monitoring/stop" : "/api/monitoring/start"

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: "POST",
    })
    const data = await response.json()

    if (response.ok) {
      monitoringActive = !monitoringActive
      updateMonitoringUI()

      if (monitoringActive) {
        showNotification("Monitoring started successfully", "success")
      } else {
        showNotification("Monitoring stopped", "info")
      }
    }
  } catch (error) {
    console.error("[v0] Error toggling monitoring:", error)
    showNotification("Failed to toggle monitoring", "error")
  }
}

// Check monitoring status
async function checkMonitoringStatus() {
  try {
    const response = await fetch(`${API_BASE}/api/monitoring/status`)
    const data = await response.json()
    monitoringActive = data.active
    updateMonitoringUI()
  } catch (error) {
    console.error("[v0] Error checking monitoring status:", error)
  }
}

// Update monitoring UI
function updateMonitoringUI() {
  const statusIndicator = document.getElementById("monitoring-status")
  const button = document.getElementById("toggle-monitoring")

  if (monitoringActive) {
    statusIndicator.classList.add("active")
    statusIndicator.querySelector(".status-text").textContent = "Monitoring Active"
    button.innerHTML = '<i class="fas fa-stop"></i> Stop Monitoring'
    button.classList.remove("btn-primary")
    button.classList.add("btn-danger")
  } else {
    statusIndicator.classList.remove("active")
    statusIndicator.querySelector(".status-text").textContent = "Monitoring Inactive"
    button.innerHTML = '<i class="fas fa-play"></i> Start Monitoring'
    button.classList.remove("btn-danger")
    button.classList.add("btn-primary")
  }
}

// Refresh all data
async function refreshData() {
  await Promise.all([loadStatistics(), loadAlerts(), loadAttackDistribution(), loadRecentPackets()])
}

// Load statistics
async function loadStatistics() {
  try {
    const response = await fetch(`${API_BASE}/api/statistics`)
    const data = await response.json()

    document.getElementById("total-packets").textContent = data.total_packets.toLocaleString()
    document.getElementById("threats-detected").textContent = data.threats_detected.toLocaleString()
    document.getElementById("normal-traffic").textContent = data.normal_traffic.toLocaleString()
    document.getElementById("model-accuracy").textContent = `${Math.round(data.model_accuracy * 100)}%`

    // Update last updated time
    const lastUpdated = new Date(data.last_updated)
    document.getElementById("last-updated").textContent = lastUpdated.toLocaleTimeString()

    // Update severity bars
    updateSeverityBars(data)
  } catch (error) {
    console.error("[v0] Error loading statistics:", error)
  }
}

// Update severity bars
function updateSeverityBars(data) {
  const severityContainer = document.getElementById("severity-bars")
  const total = data.threats_detected || 1

  // Calculate severity distribution (simulated)
  const severities = {
    Critical: Math.floor(total * 0.15),
    High: Math.floor(total * 0.25),
    Medium: Math.floor(total * 0.35),
    Low: Math.floor(total * 0.25),
  }

  const colors = {
    Critical: "#dc2626",
    High: "#ef4444",
    Medium: "#f59e0b",
    Low: "#06b6d4",
  }

  let html = ""
  for (const [severity, count] of Object.entries(severities)) {
    const percentage = total > 0 ? (count / total) * 100 : 0
    html += `
            <div class="severity-item">
                <div class="severity-label">${severity}</div>
                <div class="severity-bar-container">
                    <div class="severity-bar" style="width: ${percentage}%; background: ${colors[severity]};">
                        <span>${count}</span>
                    </div>
                </div>
            </div>
        `
  }

  severityContainer.innerHTML = html
}

// Load alerts
async function loadAlerts() {
  try {
    const response = await fetch(`${API_BASE}/api/alerts`)
    const alerts = await response.json()

    const alertsList = document.getElementById("alerts-list")
    const alertCount = document.getElementById("alert-count")

    alertCount.textContent = alerts.length

    if (alerts.length === 0) {
      alertsList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>No alerts yet</p>
                </div>
            `
      return
    }

    let html = ""
    alerts.reverse().forEach((alert) => {
      const time = new Date(alert.timestamp)
      html += `
                <div class="alert-item">
                    <div class="alert-header">
                        <span class="alert-severity ${alert.severity.toLowerCase()}">${alert.severity}</span>
                        <span class="alert-time">${time.toLocaleTimeString()}</span>
                    </div>
                    <div class="alert-message">${alert.message}</div>
                    <div class="alert-details">
                        ${alert.source_ip} → ${alert.dest_ip} | ${alert.attack_type}
                    </div>
                </div>
            `
    })

    alertsList.innerHTML = html
  } catch (error) {
    console.error("[v0] Error loading alerts:", error)
  }
}

// Load attack distribution
async function loadAttackDistribution() {
  try {
    const response = await fetch(`${API_BASE}/api/attack-distribution`)
    const distribution = await response.json()

    if (Object.keys(distribution).length === 0) {
      return
    }

    const labels = Object.keys(distribution)
    const data = Object.values(distribution)

    attackChart.data.labels = labels
    attackChart.data.datasets[0].data = data
    attackChart.update()
  } catch (error) {
    console.error("[v0] Error loading attack distribution:", error)
  }
}

// Load recent packets
async function loadRecentPackets() {
  try {
    const response = await fetch(`${API_BASE}/api/recent-packets`)
    const packets = await response.json()

    const packetsTable = document.getElementById("packets-table")

    if (packets.length === 0) {
      packetsTable.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No packets analyzed yet</p>
                </div>
            `
      return
    }

    let html = ""
    packets.forEach((packet) => {
      html += `
                <div class="packet-item">
                    <div class="packet-info">
                        <div class="packet-route">
                            ${packet.source_ip}:${packet.source_port} → ${packet.dest_ip}:${packet.dest_port}
                        </div>
                        <div class="packet-details">
                            ${packet.protocol} | ${packet.packet_size} bytes | ${new Date(packet.timestamp).toLocaleTimeString()}
                        </div>
                    </div>
                    <div class="packet-status">
                        <span class="packet-badge ${packet.is_threat ? "threat" : "normal"}">
                            ${packet.attack_type}
                        </span>
                        <span class="packet-confidence">${Math.round(packet.confidence * 100)}% confidence</span>
                    </div>
                </div>
            `
    })

    packetsTable.innerHTML = html
  } catch (error) {
    console.error("[v0] Error loading recent packets:", error)
  }
}

// Refresh attack chart
function refreshAttackChart() {
  loadAttackDistribution()
  showNotification("Chart refreshed", "success")
}

// Refresh packets
function refreshPackets() {
  loadRecentPackets()
  showNotification("Packets refreshed", "success")
}

// Reset statistics
async function resetStatistics() {
  if (!confirm("Are you sure you want to reset all statistics? This action cannot be undone.")) {
    return
  }

  try {
    const response = await fetch(`${API_BASE}/api/reset`, {
      method: "POST",
    })
    const data = await response.json()

    if (response.ok) {
      showNotification("Statistics reset successfully", "success")
      refreshData()
    }
  } catch (error) {
    console.error("[v0] Error resetting statistics:", error)
    showNotification("Failed to reset statistics", "error")
  }
}

// Show notification (simple console log for now)
function showNotification(message, type) {
  console.log(`[v0] ${type.toUpperCase()}: ${message}`)
  // You can implement a toast notification system here
}
